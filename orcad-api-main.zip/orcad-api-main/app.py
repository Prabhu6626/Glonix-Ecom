import zipfile
import os
from flask import Flask, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from gerber import load_layer
from gerber.render import RenderSettings, theme
from gerber.render.cairo_backend import GerberCairoContext
from PIL import Image

app = Flask(__name__)

UPLOAD_FOLDER = "uploads"
EXTRACT_FOLDER = "extracted"
OUTPUT_FOLDER = "output"
ALLOWED_EXTENSIONS = {"zip"}
DPI = 300  # Set image DPI for conversion

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["EXTRACT_FOLDER"] = EXTRACT_FOLDER
app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER

# Ensure required folders exist
for folder in [UPLOAD_FOLDER, EXTRACT_FOLDER, OUTPUT_FOLDER]:
    os.makedirs(folder, exist_ok=True)


def allowed_file(filename):
    """Check if the uploaded file has a ZIP extension."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_zip(zip_path, extract_to):
    """Extracts a ZIP file to a specified directory."""
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)
    return extract_to


def find_layer(directory, possible_names):
    """Search for Gerber layer files in all subdirectories."""
    for root, _, files in os.walk(directory):
        for name in possible_names:
            print(name)
            for file in files:
                print(file)
                if file.lower() == name.lower():
                    return os.path.join(root, file)
    return None  # Return None if not found


def process_gerber_layers(directory, output_folder):
    """Processes Gerber layers and generates top and bottom images."""
    os.makedirs(output_folder, exist_ok=True)
    ctx = GerberCairoContext()

    output_top = os.path.join(output_folder, "cairo_top.png")
    output_bottom = os.path.join(output_folder, "cairo_bottom.png")

    try:
        print("Processing top layers...")
        top_copper = load_layer(find_layer(directory, ["top_copper.art"]))
        top_mask = load_layer(find_layer(directory, ["top_soldermask.art"]))
        top_silk = load_layer(find_layer(directory, ["top_silkscreen.art"]))

        pcb_green = (0, 128/255, 0)
        copper_color = (184/255, 115/255, 51/255)

        ctx.render_layer(top_copper, settings=RenderSettings(color=pcb_green, alpha=0.85))
        ctx.render_layer(top_silk, settings=RenderSettings(color=theme.COLORS["white"], alpha=0.85))
        ctx.render_layer(top_mask, settings=RenderSettings(color=copper_color, alpha=0.85))

        ctx.dump(output_top)
    except Exception as e:
        print(f"Error processing top layers: {e}")
        output_top = None  # Set to None instead of returning an error string

    try:
        print("Processing bottom layers...")
        ctx.clear()
        bottom_copper = load_layer(find_layer(directory, ["bottom_copper.art"])) 
        bottom_silk = load_layer(find_layer(directory, ["bottom_silkscreen.art"])) 
        bottom_mask = load_layer(find_layer(directory, ["bottom_soldermask.art"])) 

        ctx.render_layer(bottom_copper, settings=RenderSettings(color=pcb_green, alpha=0.85))
        ctx.render_layer(bottom_silk, settings=RenderSettings(color=theme.COLORS["white"], alpha=0.85))
        ctx.render_layer(bottom_mask, settings=RenderSettings(color=copper_color, alpha=0.85))

        ctx.dump(output_bottom)
    except Exception as e:
        print(f"Error processing bottom layers: {e}")
        output_bottom = None  # Set to None instead of returning an error string

    return output_top, output_bottom  # Always return a tuple




def get_image_dimensions(image_path):
    """Calculate image dimensions in pixels and mm."""
    if not os.path.exists(image_path):
        return None, None, None, None

    with Image.open(image_path) as img:
        width_px, height_px = img.size
        width_mm = (width_px * 25.4) / DPI
        height_mm = (height_px * 25.4) / DPI

    return width_px, height_px, round(width_mm, 2), round(height_mm, 2)


@app.route("/upload", methods=["POST"])
def upload_zip():
    """Handles ZIP file upload and returns image URLs with board size."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]

    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        zip_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(zip_path)
        print(zip_path)

        # Extract files
        extract_folder_name = os.path.splitext(filename)[0]
        extract_to = os.path.join(app.config["EXTRACT_FOLDER"], extract_folder_name)
        os.makedirs(extract_to, exist_ok=True)
        extracted_dir = extract_zip(zip_path, extract_to)

        # Define unique output folder
        output_folder = os.path.join(app.config["OUTPUT_FOLDER"], extract_folder_name)
        os.makedirs(output_folder, exist_ok=True)

        # Process Gerber files
        output_top, output_bottom = process_gerber_layers(extracted_dir, output_folder)

        # Cleanup ZIP file after processing
        os.remove(zip_path)

        # Get image dimensions
        top_px_w, top_px_h, top_mm_w, top_mm_h = get_image_dimensions(output_top)
     
        # Get base URL dynamically
        base_url = request.host_url.rstrip("/")

        return jsonify({
            "message": "File uploaded and processed successfully",
            "output_top": f"{base_url}/output/{extract_folder_name}/cairo_top.png",
            "output_bottom": f"{base_url}/output/{extract_folder_name}/cairo_bottom.png",
            "top_image": {
                "dimensions_px": f"{top_px_w} x {top_px_h} pixels",
                "board_size_mm": f"{top_mm_w} x {top_mm_h} mm"
            },
           
            "storage_path": output_folder
        })

    return jsonify({"error": "Invalid file type. Only ZIP files are allowed."}), 400


@app.route("/output/<folder>/<filename>")
def get_output_image(folder, filename):
    """Serves output images."""
    return send_from_directory(os.path.join(app.config["OUTPUT_FOLDER"], folder), filename)


if __name__ == "__main__":
    app.run(debug=True,host='0.0.0.0',port=5001)