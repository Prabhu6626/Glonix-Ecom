import os
import uuid
import boto3
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
from botocore.client import Config
from dotenv import load_dotenv
from pymongo import MongoClient
from datetime import datetime
from flask_cors import CORS

# Load environment variables from .env
load_dotenv()

# Flask app
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max upload size
CORS(app)

# MongoDB setup
mongo_client = MongoClient(os.getenv("MONGO_URI"))
mongo_db = mongo_client[os.getenv("MONGO_DB")]
uploads_collection = mongo_db[os.getenv("MONGO_COLLECTION")]

# R2 (S3-compatible) setup
R2_ACCESS_KEY_ID = os.getenv("R2_ACCESS_KEY_ID")
R2_SECRET_ACCESS_KEY = os.getenv("R2_SECRET_ACCESS_KEY")
R2_ENDPOINT_URL = os.getenv("R2_ENDPOINT_URL")
R2_BUCKET_NAME = os.getenv("R2_BUCKET_NAME")
R2_PUBLIC_BASE_URL = "https://pub-c63324e3aceb438ebe579f322f902fc8.r2.dev"

r2_client = boto3.client(
    "s3",
    endpoint_url=R2_ENDPOINT_URL,
    aws_access_key_id=R2_ACCESS_KEY_ID,
    aws_secret_access_key=R2_SECRET_ACCESS_KEY,
    config=Config(signature_version="s3v4"),
    region_name="auto"
)

# Upload endpoint
@app.route('/products', methods=['POST'])
def upload_product_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part in request"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400

    # username = request.form.get('username')
    product_id = request.form.get('product_id')

    if not product_id:
        return jsonify({"error": "Missing username or order_id"}), 400

    filename = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{filename}"
    s3_key = f"products/{unique_name}"  # different folder

    try:
        # Upload to R2
        r2_client.upload_fileobj(file, R2_BUCKET_NAME, s3_key)

        file_url = f"{R2_PUBLIC_BASE_URL}/{s3_key}"
        uploaded_at = datetime.utcnow()

        # Store metadata in MongoDB
        uploads_collection.insert_one({
            "filename": filename,
            "product_id": product_id,
            "s3_key": s3_key,
            "file_url": file_url,
            "uploaded_at": uploaded_at,
            "category": "product"  # Optional: tag it
        })

        return jsonify({
            "message": "Product file uploaded and metadata saved",
            "file_url": file_url,
            "uploaded_at": uploaded_at.isoformat()
        }), 200

    except Exception as e:
        app.logger.exception("Product upload failed")
        return jsonify({"error": "Internal server error"}), 500
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part in request"}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
    order_id = None
    quotation_id = None

    username = request.form.get('username')
    if request.form.get('order_id'):
        order_id = request.form.get('order_id')
    if request.form.get('quotation_id'):
        quotation_id = request.form.get('quotation_id')

    if not username:
        return jsonify({"error": "Missing username"}), 400

    if (not order_id) and (not quotation_id):
        return jsonify({"error": "Missing order_id or quotation_id"}), 400

    filename = secure_filename(file.filename)
    unique_name = f"{uuid.uuid4().hex}_{filename}"
    s3_key = f"uploads/{unique_name}"

    try:
        # Upload to R2
        r2_client.upload_fileobj(file, R2_BUCKET_NAME, s3_key)

        file_url = f"{R2_PUBLIC_BASE_URL}/{s3_key}"

        # Prepare metadata
        metadata = {
            "filename": filename,
            "username": username,
            "s3_key": s3_key,
            "file_url": file_url,
            "uploaded_at": datetime.utcnow()
        }

        if order_id:
            metadata["order_id"] = order_id
        else:
            metadata["quotation_id"] = quotation_id

        # Store metadata in MongoDB
        uploads_collection.insert_one(metadata)

        return jsonify({
            "message": "File uploaded and metadata saved",
            "file_url": file_url
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Get uploads by order ID
@app.route('/uploads/order/<order_id>', methods=['GET'])
def get_uploads_by_order(order_id):
    results = list(
        uploads_collection.find({"order_id": order_id}, {"_id": 0, "s3_key": 0}).sort("uploaded_at", -1)
    )
    return jsonify(results), 200

# Get uploads by username
@app.route('/uploads/user/<username>', methods=['GET'])
def get_uploads_by_username(username):
    results = list(
        uploads_collection.find({"username": username}, {"_id": 0, "s3_key": 0}).sort("uploaded_at", -1)
    )
    return jsonify(results), 200

if __name__ == '__main__':
    app.run(host='0.0.0.0',port=5001,debug=True)